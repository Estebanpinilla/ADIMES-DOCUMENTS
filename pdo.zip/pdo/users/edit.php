<?php require '../config/app.php'; ?>
<?php include '../config/security_admin.php'; ?>
<?php include '../config/bd.php'; ?>
<?php include '../includes/header.inc'; ?>
<?php include '../includes/navbar.inc'; ?>

<br><br>
<div class="container">
	<div class="row">
		<div class="col-md-6 offset-md-3 ">
			<h2 class="text-center text-muted text-center my-5"><i class="fa fa-edit"></i>Mofidicar Usuarios</h2>
			<hr>
			<nav arial-label="breadcrumb">
				<ol class="breadcrumb">
					<li class="breadcrumb-item"> <a href="index.php" class="link-success">Módulo Usuarios</a></li>
					<li class="breadcrumb-item active">Modificar Usuarios</li>
				</ol>
			</nav>
			<?php $usuario = mostrarUsuario($con, $_GET['documento']); ?>
			<?php foreach ($usuario as $urow): ?>
			<form action="" method="post" enctype="multipart/form-data">
					<div class="form-group">
						<span>*Tipo de documento:</span>
						<input type="text" class="form-control" name="TipoDocumento" value="<?php echo $urow['TipoDocumento'];?>" required readonly>
					</div>
					<div class="form-group">
						<span>*Numero de documento:</span>
						<input type="number" class="form-control" name="documento" value="<?php echo $urow['documento'];?>" required readonly>
					</div>
					<div class="form-group">
						<span>*Nombres:</span>
						<input type="text" class="form-control" name="nombres" value="<?php echo $urow['nombres'];?>" required>
					</div>
					<div class="form-group">
						<span>*Apellidos:</span>
						<input type="text" class="form-control" name="Apellidos" value="<?php echo $urow['Apellidos'];?>" required>
					</div>
					<div class="form-group">
						<span>*Correo:</span>
						<input type="email" class="form-control" name="correo" value="<?php echo $urow['correo'];?>" required>
					</div>
					<div class="form-group">
						<span>*Programa de formación: </span>
						<input type="text" class="form-control" name="ProgramaFormacion" value="<?php echo $urow['ProgramaFormacion'];?>" required>
					</div>
					<div class="form-group">
						<span>*Ficha:</span>
						<input type="number" class="form-control" name="ficha" value="<?php echo $urow['ficha'];?>" required>
					</div>
					<div class="form-group">
						<span>Foto:</span>
						<input type="file" class="form-control" name="foto"  accept="imgs/*">
					</div>
					<div class="form-group">
						<select name="rol" class="form-control">
							<option value="<?php echo $urow['rol'];?>"><?php echo $urow['rol'];?></option>
							<option value="Aprendiz">Aprendiz</option>
							<option value="Instructor">Instructor</option>
						</select>
					</div>
					<div class="form-group">
						<button type="submit" class="btn btn-success"> <i class="fa fa-save"></i> Guardar </button>
					</div>
				</form>
			<?php endforeach ?>
			<?php 
			 	if($_POST){
			 		$TipoDocumento =$_POST['TipoDocumento'];
			 		$documento =$_POST['documento'];
			 		$nombres =$_POST['nombres'];
			 		$Apellidos =$_POST['Apellidos'];
			 		$correo =$_POST['correo'];
			 		$ProgramaFormacion =$_POST['ProgramaFormacion'];
			 		$ficha =$_POST['ficha'];
			 		$url = '../';
			 		$foto = $url.$_FILES['foto']['name'];
			 		move_uploaded_file($_FILES['foto']['tmp_name'], '../'.$url.$_FILES['foto']['name']);
			 		$rol =$_POST['rol'];




			 		if (modificarUsuario($con,  $TipoDocumento, $documento, $nombres, $Apellidos, $correo, $ProgramaFormacion, $ficha, $foto, $rol)){
			 			$_SESSION['type'] = 'success';
						$_SESSION['message'] = 'EL usuario  se Modifico Correctamente';
			 		}else{
			 			$_SESSION['type'] = 'danger';
						$_SESSION['message'] = 'EL usuario no se Modifico Correctamente';
			 		}

			 }


			 ?>
		</div>
	</div>
</div>
<?php $con = null; ?>