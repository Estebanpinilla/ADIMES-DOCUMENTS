<?php require '../config/app.php'; ?>
<!-- <?php include '../config/security_admin.php'; ?> -->
<?php include '../config/bd.php'; ?>
<?php include '../includes/header.inc'; ?>
<?php include '../includes/navbar.inc'; ?>


<div class="container">
	<div class="row">
		<div class="col-md-10 offset-md-1">
			<br><br>
			<h2 class="text-center text-muted text-center my-5"><i class="fa fa-users"></i> Lista de usuarios</h2>
			<hr>
			<?php if ($_SESSION['urol'] == 'Admin'): ?>
				<button type="button" class="btn bgf w-25" data-toggle="modal" data-target="#exampleModalCenter" style="color: white">Agregar usuario
				</button><br>
				<hr>
			<?php endif ?>
			
			<table class="table table-striped table-hover">
				<?php if ($_SESSION['urol'] == 'Admin'): ?>
					<thead class="gbt">
						<?php else: ?>
							<thead class="bg-primary" style="color: white">
							<?php endif ?>
							<tr>
								<th class="text-center">Foto</th>
								<th class="text-center">Documento</th>
								<th class="text-center">Nombre</th>
								<th class="text-center">Apellidos</th>
								<th class="text-center">Rol</th>
								<th class="text-center">Acciones</th>
							</tr>
						</thead>
						<tbody>
						<?php if ($_SESSION['urol'] == 'Admin'): ?>
							<?php $listu = listaUsuarios($con);  ?>
						<?php endif ?>
						<?php if ($_SESSION['urol'] == 'Instructor'): ?>
							<?php $listu = listaUsuariosA($con);  ?>
						<?php endif ?>
							<?php foreach ($listu as $urow ) : ?>
								<tr>
									<td class="text-center"><img src="../<?php echo $urow['foto']; ?>" width="50px"></td>
									<td class="text-center"> <?php echo $urow['documento'];?></td>
									<td class="text-center"><?php echo $urow['nombres'] ?></td>
									<td class="text-center"><?php echo $urow['Apellidos'] ?></td>
									<td class="text-center"><?php echo $urow['rol'] ?></td>
									<td class="text-center">
										<a href="show.php?documento=<?php echo $urow['documento']; ?>" class="btn btn-outline-primary">
											<i class="fa fa-search"></i>
										</a>
										<?php if ($_SESSION['urol'] == "Admin"): ?>
											<a href="edit.php?documento=<?php echo $urow['documento']; ?>" class="btn btn-outline-success">
												<i class="fa fa-edit"></i>
											</a>
											<a href="javascript:;" class="btn btn-outline-danger btn-delete" data-id="<?php echo $urow['documento']; ?>">
												<i class="fa fa-trash"></i>
											</a>
											<?php else: ?>
												<a href="seguimiento.php?documento=<?php echo $urow['documento']; ?>" class="btn btn-outline-primary">
													<i class="far fa-calendar-alt"></i>
												</a>
											<?php endif ?>
										</td>
									</tr>
								<?php endforeach ?> 
							</tbody>
						</table><br><br><br><br><br><br><br>
					</div>
				</div>
			</div>

			<!-- modal -->
			<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
				<div class="modal-dialog modal-dialog-centered" role="document">
					<div class="modal-content">
						<div class="modal-header bgf">
							<h5 class="modal-title text-white Hand" id="exampleModalLongTitle">Agregar Usuario</h5>
							<button type="button" class="close" data-dismiss="modal" aria-label="Close">
								<span aria-hidden="true">&times;</span>
							</button>
						</div>
						<div class="modal-body">
							<!-- multistep form -->
							<form  action="" id="msform" method="post" enctype="multipart/form-data">
								<!-- fieldsets -->
								<fieldset class="active">
									<h2 class="fs-title">Crea tu perfil</h2>
									<h3 class="fs-subtitle">Paso 1</h3>
									<select name="TipoDocumento" class="custom-select" style="margin-bottom: 10px">
										<option value="">Tipo Documento...</option>
										<option value="TI" <?php if(['TipoDocumento'] == "TI") echo "selected"; ?> >Tarjeta Identidad</option>
										<option value="CC" <?php if(['TipoDocumento'] == "CC") echo "selected"; ?> >Cedula Ciudadania</option>
										<option value="CE" <?php if(['TipoDocumento'] == "CE") echo "selected"; ?> >Cedula Extranjera</option>
									</select>
									<input type="number" class="form-control" name="documento" placeholder="Documento de identidad" required>
									<input type="text" class="form-control" name="nombres" placeholder="Nombre" required>
									<input type="text" class="form-control" name="Apellidos" placeholder="Apellidos" required>
									<input type="button" name="next" class="next action-button" value="Next" />
								</fieldset>
								<fieldset>
									<h2 class="fs-title">Curso</h2>
									<h3 class="fs-subtitle">Paso 2</h3>
									<select name="nivelFormacion" class="custom-select" style="margin-bottom: 10px" required>
										<option value="">Nivel de formación...</option>
										<option value="Tecnico" <?php if(['nivelFormacion'] == "Tecnico") echo "selected"; ?> >Técnico</option>
										<option value="Tecnologo" <?php if(['nivelFormacion'] == "Tecnologo") echo "selected"; ?> >Tecnólogo</option>
										<option value="Profesional" <?php if(['nivelFormacion'] == "Profesional") echo "selected"; ?> >Profesional</option>
										<option value="Posgrado" <?php if(['nivelFormacion'] == "Posgrado") echo "selected"; ?> >Posgrado</option>
									</select>
									<input type="text" class="form-control" name="titulacion" placeholder="Titulación" required>
									<select name="contrato" class="custom-select" style="margin-bottom: 10px" required>
										<option value="">Tipo Contrato...</option>
										<option value="Planta" <?php if(['contrato'] == "DP") echo "selected"; ?> >Planta</option>
										<option value="Contratista" <?php if(['contrato'] == "CT") echo "selected"; ?> >Contratista</option>
									</select>
									<input type="button" name="next" class="next action-button" value="Next" />
								</fieldset>
								<fieldset>
									<h2 class="fs-title">Informacion Adicional</h2>
									<h3 class="fs-subtitle">Paso 3</h3>
									<input type="email" class="form-control" name="correo" placeholder="Correo Electronico" required>
									<input type="password" class="form-control" name="clave" placeholder="Contraseña" required>
									<select name="rol" class="custom-select" style="margin-bottom: 10px">
										<option value="">Rol...</option>
										<option value="Instructor" <?php if(['rol'] == "Instructor") echo "selected"; ?> >Instructor</option>
									</select>
									<input type="submit" name="submit" class="submit action-button" value="Submit" />
								</fieldset>
							</form>
						</div>
					</div>
				</div>
			</div>
			<?php 
			if($_POST){
				$TipoDocumento =$_POST['TipoDocumento'];
				$documento =$_POST['documento'];
				$nombres =$_POST['nombres'];
				$Apellidos =$_POST['Apellidos'];
				$nivelFormacion =$_POST['nivelFormacion'];
				$titulacion = $_POST['titulacion'];
				$contrato = $_POST['contrato'];
				$correo =$_POST['correo'];
				$clave =md5($_POST['clave']);
				$rol =$_POST['rol'];

				adicionarUsuarioI($con, $TipoDocumento, $documento, $nombres, $Apellidos, $nivelFormacion, $titulacion, $contrato, $correo, $clave, $rol);
				if (adicionarUsuario($con, $TipoDocumento, $documento, $nombres, $Apellidos, $nivelFormacion, $titulacion, $contrato, $correo, $clave, $rol)){
					$_SESSION['type'] = 'success';
					$_SESSION['message'] = 'EL usuario  se Adiciono Correctamente';
				}else{
					$_SESSION['type'] = 'danger';
					$_SESSION['message'] = 'EL usuario no se Adiciono Correctamente';
				}

			}


			?>
			<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>

			<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js" integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ" crossorigin="anonymous"></script>

			<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous"></script>

			<script src="../public/js/bootstrap.min.js"></script>
			<!-- <script src="../public/js/sweetalert2.all.js"></script> -->
			<!-- <script src="sweetalert2.min.js"></script> -->
			<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js" ></script>
			<script src="//cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>
			<script>
				$('.fm2, .fm3').hide();

				$('.next').click(function() {
					$act = $('fieldset.active');
					if($act.index() < 3) {
						$act.hide().removeClass('active');
						$act.next().fadeIn('slow').addClass('active');
					}
					;
				});

			</script>
			<script>
//jQuery time
var current_fs, next_fs, previous_fs; //fieldsets
var left, opacity, scale; //fieldset properties which we will animate
var animating; //flag to prevent quick multi-click glitches

$(".next").click(function(){
	if(animating) return false;
	animating = true;

	current_fs = $(this).parent();
	next_fs = $(this).parent().next();

  //activate next step on progressbar using the index of next_fs
  $("#progressbar li").eq($("fieldset").index(next_fs)).addClass("active");
  
  //show the next fieldset
  next_fs.show(); 
  //hide the current fieldset with style
  current_fs.animate({opacity: 0}, {
  	step: function(now, mx) {
      //as the opacity of current_fs reduces to 0 - stored in "now"
      //1. scale current_fs down to 80%
      scale = 1 - (1 - now) * 0.2;
      //2. bring next_fs from the right(50%)
      left = (now * 50)+"%";
      //3. increase opacity of next_fs to 1 as it moves in
      opacity = 1 - now;
      current_fs.css({
      	'transform': 'scale('+scale+')',
      	'position': 'absolute'
      });
      next_fs.css({'left': left, 'opacity': opacity});
  }, 
  duration: 800, 
  complete: function(){
  	current_fs.hide();
  	animating = false;
  }, 
    //this comes from the custom easing plugin
    easing: 'easeInOutBack'
});
});

$(".previous").click(function(){
	if(animating) return false;
	animating = true;

	current_fs = $(this).parent();
	previous_fs = $(this).parent().prev();

  //de-activate current step on progressbar
  $("#progressbar li").eq($("fieldset").index(current_fs)).removeClass("active");
  
  //show the previous fieldset
  previous_fs.show(); 
  //hide the current fieldset with style
  current_fs.animate({opacity: 0}, {
  	step: function(now, mx) {
      //as the opacity of current_fs reduces to 0 - stored in "now"
      //1. scale previous_fs from 80% to 100%
      scale = 0.8 + (1 - now) * 0.2;
      //2. take current_fs to the right(50%) - from 0%
      left = ((1-now) * 50)+"%";
      //3. increase opacity of previous_fs to 1 as it moves in
      opacity = 1 - now;
      current_fs.css({'left': left});
      previous_fs.css({'transform': 'scale('+scale+')', 'opacity': opacity});
  }, 
  duration: 800, 
  complete: function(){
  	current_fs.hide();
  	animating = false;
  }, 
    //this comes from the custom easing plugin
    easing: 'easeInOutBack'
});
});

</script>

<?php include '../includes/footer.inc'; ?>
<?php $con = null; ?>

