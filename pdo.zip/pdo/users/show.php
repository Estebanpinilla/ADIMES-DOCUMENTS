<?php require '../config/app.php'; ?>
<?php include '../config/bd.php'; ?>
<?php include '../includes/header.inc'; ?>
<?php include '../includes/navbar.inc'; ?>
<link rel="stylesheet" href="../public/css/custom.css">

<div class="container">
	<div class="row">
		<div class="col-md-8 offset-md-2 text-center">
			<br><br><br><br>
			<nav arial-label="breadcrumb">
				<ol class="breadcrumb">
					<li class="breadcrumb-item"><strong><a href="index.php" class="text-primary">Modulo Usuarios</a></strong></li>
					<li class="breadcrumb-item active"> Consultar Usuario </li>
				</ol>
			</nav>
			<?php $puntuacion = mostrarPuntaje($con, $_GET['documento']); ?>
			<?php $usuario = mostrarUsuario($con, $_GET['documento']); ?>
			<section class="carnet">
				<?php foreach ($usuario as $urow): ?>
					<h4><?php echo $urow['ProgramaFormacion']; ?></h4>
					<div class="cfoto">
						<img src="../<?php echo $urow['foto']; ?>" width="145px" height="145px" data-img="<?php echo $urow['foto']; ?>" style="cursor: zoom-in;">
					</div>
					<div class="cinfo">
						<ul class="text-left">
							<?php if ($urow['rol'] == 'Aprendiz'): ?>
								<li><strong>Documento de identidad:</strong><br>
									<?php echo $urow['documento']; ?>
								</li>
								<li><strong>Nombre completo:</strong><br>
									<?php echo $urow['nombres']; ?>
									<?php echo $urow['Apellidos']; ?>	
								</li>
								<li><strong>Correo electrónico:</strong><br>
									<?php echo $urow['correo']; ?>		
								</li>
								<li><strong>ID:</strong><br>
									<?php echo $urow['ficha']; ?>	
								</li>
								<li><strong>Rol:</strong><br>
									<?php echo $urow['rol']; ?>
								</li>
								<li style="display: inline-block;"><strong>Resultado:</strong><br>
									<?php foreach ($puntuacion as $prow): ?>	
										<?php echo $prow['puntaje']; ?>	
									<?php endforeach ?>
								</li>
							<?php endif ?>
							<?php if ($urow['rol'] == 'Instructor'): ?>
								<li><strong>Documento de identidad:</strong><br>
									<?php echo $urow['documento']; ?>
								</li>
								<li><strong>Nombre completo:</strong><br>
									<?php echo $urow['nombres']; ?>
									<?php echo $urow['Apellidos']; ?>	
								</li>
								<li><strong>Correo electrónico:</strong><br>
									<?php echo $urow['correo']; ?>		
								</li>
								<li><strong>Nivel de formación:</strong><br>
									<?php echo $urow['nivelFormacion']; ?>	
								</li>
								<li><strong>Titulacion:</strong><br>
									<?php echo $urow['titulacion']; ?>
								</li>
								<li><strong>Contrato:</strong><br>
									<?php echo $urow['contrato']; ?>
								</li>
							<?php endif ?>
						</ul>																	
					</div><br><br><br>
					<?php if ( $urow['rol'] == 'Aprendiz'): ?>
						<div class="container-fluid bg-success text-left cf">
						<?php endif ?>
						<?php 
						if ($urow['rol'] == 'Instructor') {
							if ($urow['contrato'] == 'Planta') {
								echo "<div class='container-fluid bgt text-left cf'>";
							}
							if ($urow['contrato'] == 'Contratista') {

								echo "<div class='container-fluid bgf text-left cf'>";
							}
						}
						?>

						<div class="cuadrito"></div>
						<p class="col-9 ctext">
							SENA REGIONAL CALDAS <br>
							CENTRO DE PROCESOS INDUSTRIALES Y CONSTRUCCION <br>
							APRENDIZ
						</p>
					</div>
				<?php endforeach ?>
			</section>
		</div>
	</div>
</div><br><br>
<?php $con = null; ?>