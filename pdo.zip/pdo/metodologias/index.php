<?php require '../config/app.php'; ?>
<?php include '../config/bd.php'; ?>
<?php include '../includes/header.inc'; ?>
<?php include '../includes/navbar.inc'; ?>

<div class="container">
	<div class="row">
		<div class="col-md-8 offset-md-2 ">
			<h1 class="text-center text-muted text-center"><i class="fa fa-book"></i>Módulo Usuarios</h1>
			<hr>
			<h3>Realizar seguimiento al aprendiz:</h3>
			<table class="table table-striped table-hover">
				<thead>
					<tr>
						<th>Foto</th>
						<th>Documento identidad</th>
						<th>Nombre Completo</th>
						<th>Ficha</th>
						<th>Acciones</th>

					</tr>
				</thead>
				<tbody>
					<?php $listu = listaUsuarios($con);  ?>
					<?php foreach ($listu as $urow ) : ?>
					<tr>
						<td><img src="../<?php echo $urow['foto']; ?>" width="50px"></td>
						<td> <?php echo $urow['documento'];?></td>
						<td><?php echo $urow['nombres'] ?></td>
						<td><?php echo $urow['ficha'] ?></td>
						<td>
							<a href="show.php?documento=<?php echo $urow['documento']; ?>" class="btn btn-outline-primary">
								<i class="far fa-calendar-alt"></i>
							</a>
							
						</td>
					</tr>
					<?php endforeach ?> 
				</tbody>
			</table>
		</div>
	</div>
</div>
<?php $con = null; ?>
<?php include '../includes/footer.inc'; ?>