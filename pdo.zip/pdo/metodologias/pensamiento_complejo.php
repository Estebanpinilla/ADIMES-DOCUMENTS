<?php require '../config/app.php'; ?>
<?php include '../config/bd.php'; ?>
<?php include '../includes/header.inc'; ?>
<?php include '../includes/navbar.inc'; ?>

<link rel="stylesheet" href="../public/css/bootstrap.min.css">
<link rel="stylesheet" href="../public/css/fontawesome-all.min.css">
<link rel="stylesheet" href="../public/css/custom.css">
<link rel="stylesheet" href="../public/css/owl.carousel.min.css">
<link rel="stylesheet" href="../public/css/owl.theme.default.min.css">

<h2  class="text-center"><i class="fa fa-user"></i> Bienvenido Instructor </h2>
<hr id="ba" class="col-9">
<br><br><br>
<div class="container">
	<div id="r2" class="row">
		<div class="col-md-8 offset-md-2 text-center">
			<table class="table table-hover">
				<thead>
					<tr>
						<th colspan="4" class="gbt" class="text-center">Actividades a realizar</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td colspan="3">
							<label><strong>Escala de comprensión:</strong></label>
							<br>
							<p class="text-justify">Estas actividades ayudan a mejorar habilidades de formación de conceptos verbales, expresión de relaciones entre conceptos,
							riqueza y precisión en la definición de vocablos, comprensión social, juicio práctico, conocimientos adquiridos y agilidad e
							intuición verbal. </p>
							</td>
						<td><button name="boton1" type="button" id="boton1" value="boton 1"  class="btn btn-outline-info" onclick="descarga('../public/archivos/ESCALA DE COMPRENSION (1).pdf')">
							<img src="../public/imgs/comprension/comprension.png" width="200px" height="200px"></button>
					</td>
					<tr>
						<td colspan="3">
							<label><strong>Escala de Memoria:</strong></label>
							<br>
							<p class="text-justify">Estas actividades ayudan a mejorar habilidades prácticas constructivas, formación  y clasificación de conceptos noverbales,
							análisis visual y procesamiento simultáneo. </p>
							</td>
						<td><button name="boton2" type="button" id="boton2" value="boton "  class="btn btn-outline-info" onclick="descarga('../public/archivos/')">
							<img src="../public/imgs/memoria/memoria.png" width="200px" height="200px"></button>
					</td>
					<tr>
						<td colspan="3">
							<label><strong>Escala de Razonamiento:</strong></label>
							<br>
							<p class="text-justify"> Estas actividades ayudan a mejorarla capacidad de retención y almacenamiento de información, de operar mentalmente con esta información, transformarla y generar nueva información.</p>
							</td>
						<td><button name="boton3" type="button" id="boton3" value="boton 3"  class="btn btn-outline-info" onclick="descarga('../public/archivos/ESCALA DE RAZONAMIENTO.pdf')">
							<img src="../public/imgs/razonamiento/razonamiento.png" width="200px" height="200px"></button>
					</td>
					<tr>
						<td colspan="3">
							<label><strong>Escala de Velocidad de pensamiento:</strong></label>
							<br>
							<p class="text-justify">Estas actividades ayudan a mejorar la Velocidad de Procesamiento de la información,  la capacidad para focalizar la atención, explorar, ordenar y/o
							discriminar información visual con rapidez y eficacia. </p>
							</td>
						<td><button name="boton4" type="button" id="boton4" value="boton 4"  class="btn btn-outline-info" onclick="descarga('../public/archivos/Actividades  velocidad de pensamiento.pdf')">
							<img src="../public/imgs/velocidad/velocidad de pensamiento.png" width="200px" height="200px"></button>
					</td>
					
					
				</tbody>
			</table>
			</table>
		</div>
	</div>
</div>


<script>
	function descarga(archivo) {
		document.location = archivo;
	}

</script>
