<?php require '../config/app.php'; ?>
<?php include '../config/bd.php'; ?>
<?php include '../includes/header.inc'; ?>
<?php include '../includes/navbar.inc'; ?>

<link rel="stylesheet" href="../public/css/bootstrap.min.css">
<link rel="stylesheet" href="../public/css/fontawesome-all.min.css">
<link rel="stylesheet" href="../public/css/custom.css">
<link rel="stylesheet" href="../public/css/owl.carousel.min.css">
<link rel="stylesheet" href="../public/css/owl.theme.default.min.css">

<div class="container">
	<div id="r2" class="row">
		<div class="col-md-8 offset-md-2">
			<h1>FLEPPED CLASSROM</h1>
				<p>“El flipped classroom es un modelo
					pedagógico que transfiere el trabajo de determinados procesos de aprendizaje
					fuera del aula y utiliza el tiempo de clase, junto con la experiencia docente para
					facilitar y potenciar otros procesos de adquisición practica del conocimiento dentro
					del aula”</p>
				<label>A continuación se dara una explicacón de como implementar esta metodología en su calse:</label>
				<p>Una clase flip o aula inversa iniciaría a partir de la reflexión del video de
					contenidos visto previamente por los estudiantes y las preguntas que
					puedan tener sobre el mismo. En este punto desempeñan un papel
					importante e imprescindible la autonomía y responsabilidad del estudiante,
					no solo en la visualización de un material de trabajo, sino en su disposición
					completa para su análisis y el desarrollo de los cuestionamientos que surjan
					sobre el mismo; en otras palabras, los estudiantes deben ser conscientes
				    de su propio aprendizaje y emplear lo necesario para su consecución.</p>

		</div>
	</div>
</div>