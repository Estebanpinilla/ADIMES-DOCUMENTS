<?php require '../config/app.php'; ?>
<?php include '../config/bd.php'; ?>
<?php include '../includes/header.inc'; ?>
<?php include '../includes/navbar.inc'; ?>

<link rel="stylesheet" href="../public/css/bootstrap.min.css">
<link rel="stylesheet" href="../public/css/fontawesome-all.min.css">
<link rel="stylesheet" href="../public/css/custom.css">
<link rel="stylesheet" href="../public/css/owl.carousel.min.css">
<link rel="stylesheet" href="../public/css/owl.theme.default.min.css">

<h2  class="text-center text-muted my-5"><i class="fa fa-user"></i> Bienvenido Instructor </h2>
<hr  class="col-9" style="margin-bottom: 100px;">
<div class="container">
	<div id="r2" class="row">
		<div class="col-md-8 offset-md-2 text-center">
			<table class="table table-hover">
				<thead class="bgf">
					<tr>
						<th colspan="4" class="gbt">Metodologías</th>
						<th colspan="2" class="gbt">Consultar</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td colspan="4">FLEPPED CLASSROM</td>
						<td><a class="btn btn-success" href="flepped_classrom.php" role="button"><i class="fa fa-edit"></i></a></td>
					</tr>
					<tr>
						<td colspan="4">PENSAMIENTO COMPLEJO</td>
						<td><a class="btn btn-success" href="pensamiento_complejo.php" role="button"><i class="fa fa-edit"></i></a></td>
					</tr>
					<tr>
						<td colspan="4">GAMIFICACIÓN</td>
						<td><a class="btn btn-success" href="#" role="button"><i class="fa fa-edit"></i></a></td>
					</tr>
				</tbody>
			</table>
		</div>
	</div>
</div>