<?php

// Sesiones
session_start();

// Variables (Rutas Relativas/Absolutas)
$url_site   = 'http://localhost/adimes/pdo/';
$url_public = $url_site.'public/';
$url_css    = $url_public.'css/';
$url_js     = $url_public.'js/';

// Configuración BD
$host = 'localhost';
$user = 'root';
$pass = '';
$nmdb = 'adimes';
$con = mysqli_connect($host, $user, $pass, $nmdb);

if (mysqli_connect_errno()) {
	// echo "Error: ".mysqli_connect_error();
	$statusConn = false;
}else{
	// echo "Se ha conectado a MYSQL";
	$statusConn = true;
}



