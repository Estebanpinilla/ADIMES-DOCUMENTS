<?php
	/* = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = 
	// Conectar Base de Datos
	= = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = */
	try {
		$con = new PDO("mysql:host=localhost; dbname=adimes",'root',''); 
		$con->exec('set names utf8');
		$con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		// echo "Se ha conectado a la base de datos";
	} catch (PDOException $e) {
		echo $e->getMessage();
	}
	/* = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = 
	// Login
	= = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = */
	function login($con, $documento, $clave) {
		try {
			$sql = "SELECT * FROM usuarios WHERE documento = :documento AND clave = :clave LIMIT 1";
			$stm = $con->prepare($sql);
			$stm->bindparam(':documento', $documento);
			$stm->bindparam(':clave', $clave);
			$stm->execute();
			if($stm->rowCount() > 0) {
				$urow = $stm->fetch(PDO::FETCH_ASSOC);
				$_SESSION['udocumento'] = $urow['documento'];
				$_SESSION['unombre']    =  $urow['nombres'];
				$_SESSION['ufoto']      =  $urow['foto'];
				$_SESSION['urol']       =  $urow['rol'];
				return true;
			} else {
				return false;
			}	
		} catch (PDOException $e) {
			echo $e->getMessage();
		}
	}

	/* = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = 
	// usuarios
	= = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = */

	function listaUsuarios($con) {
		try {
			$sql = "SELECT * FROM usuarios";
			$stm = $con->prepare($sql);
			$stm->execute();

			return $stm->fetchAll();
		} catch (PDOException $e) {
			echo $e->getMessage();
		} 
	}

	function listaUsuariosA($con) {
		try {
			$sql = "SELECT * FROM aprendices";
			$stm = $con->prepare($sql);
			$stm->execute();

			return $stm->fetchAll();
		} catch (PDOException $e) {
			echo $e->getMessage();
		} 
	}


	function mostrarUsuario($con, $id) {
		try {
			$sql = "SELECT * FROM usuarios WHERE documento = :id";
			$stm = $con->prepare($sql);
			$stm->bindparam(":id", $id);
			$stm->execute();

			return $stm->fetchAll();
		} catch (PDOException $e) {
			echo $e->getMessage();
		} 
	}

	function mostrarPuntaje($con, $id) {
		try {
			$sql = "SELECT * FROM resultadotest WHERE documento = :id";
			$stm = $con->prepare($sql);
			$stm->bindparam(":id", $id);
			$stm->execute();

			return $stm->fetchAll();
		} catch (PDOException $e) {
			echo $e->getMessage();
		} 
	}


	function adicionarUsuario($con, $TipoDocumento, $documento, $nombres, $Apellidos, $nivelFormacion, $titulacion, $contrato, $correo, $clave, $rol) {
		try {
			$sql = "INSERT INTO usuarios (TipoDocumento, documento, nombres, Apellidos, nivelFormacion, titulacion, contrato, correo, clave, rol) VALUES (:TipoDocumento, :documento, :nombres, :Apellidos, :nivelFormacion, :titulacion, :contrato, :correo, :clave, :rol)";
			$stm = $con->prepare($sql);
			$stm->bindparam(":TipoDocumento", $TipoDocumento);
			$stm->bindparam(":documento", $documento);
			$stm->bindparam(":nombres", $nombres);
			$stm->bindparam(":Apellidos", $Apellidos);
			$stm->bindparam(":nivelFormacion", $nivelFormacion);
			$stm->bindparam(":titulacion", $titulacion);
			$stm->bindparam(":contrato", $contrato);
			$stm->bindparam(":correo", $correo);
			$stm->bindparam(":clave", $clave);
			$stm->bindparam(":rol", $rol);



			if($stm->execute()) {
				return true;
			} else {
				return false;
			}
		} catch (PDOException $e) {
			echo $e->getMessage();
		} 
	}

	function adicionarUsuarioI($con, $TipoDocumento, $documento, $nombres, $Apellidos, $nivelFormacion, $titulacion, $contrato, $correo, $clave, $rol) {
		try {
			$sql = "INSERT INTO instructores (TipoDocumento, documento, nombres, Apellidos, nivelFormacion, titulacion, contrato, correo, clave, rol) VALUES (:TipoDocumento, :documento, :nombres, :Apellidos, :nivelFormacion, :titulacion, :contrato, :correo, :clave, :rol)";
			$stm = $con->prepare($sql);
			$stm->bindparam(":TipoDocumento", $TipoDocumento);
			$stm->bindparam(":documento", $documento);
			$stm->bindparam(":nombres", $nombres);
			$stm->bindparam(":Apellidos", $Apellidos);
			$stm->bindparam(":nivelFormacion", $nivelFormacion);
			$stm->bindparam(":titulacion", $titulacion);
			$stm->bindparam(":contrato", $contrato);
			$stm->bindparam(":correo", $correo);
			$stm->bindparam(":clave", $clave);
			$stm->bindparam(":rol", $rol);


			if($stm->execute()) {
				return true;
			} else {
				return false;
			}
		} catch (PDOException $e) {
			echo $e->getMessage();
		} 
	}

	function registrarUsuario($con, $TipoDocumento, $documento, $nombres, $Apellidos, $correo, $clave, $ProgramaFormacion, $ficha, $rol) {
		try {
			$sql = "INSERT INTO usuarios (TipoDocumento, documento, nombres, Apellidos, correo, clave, ProgramaFormacion, ficha, rol) VALUES (:TipoDocumento, :documento, :nombres, :Apellidos, :correo, :clave, :ProgramaFormacion, :ficha, :rol)";
			
			$stm = $con->prepare($sql);
			$stm->bindparam(":TipoDocumento", $TipoDocumento);
			$stm->bindparam(":documento", $documento);
			$stm->bindparam(":nombres", $nombres);
			$stm->bindparam(":Apellidos", $Apellidos);
			$stm->bindparam(":correo", $correo);
			$stm->bindparam(":clave", $clave);
			$stm->bindparam(":ProgramaFormacion", $ProgramaFormacion);
			$stm->bindparam(":ficha", $ficha);
			$stm->bindparam(":rol", $rol);

			if($stm->execute()) {
				return true;
			} else {
				return false;
			}
		} catch (PDOException $e) {
			echo $e->getMessage();
		} 
	}

	function registrarUsuarioA($con, $TipoDocumento, $documento, $nombres, $Apellidos, $correo, $clave, $ProgramaFormacion, $ficha, $rol) {
		try {
			$sql = "INSERT INTO aprendices (TipoDocumento, documento, nombres, Apellidos, correo, clave, ProgramaFormacion, ficha, rol) VALUES (:TipoDocumento, :documento, :nombres, :Apellidos, :correo, :clave, :ProgramaFormacion, :ficha, :rol)";
			
			$stm = $con->prepare($sql);
			$stm->bindparam(":TipoDocumento", $TipoDocumento);
			$stm->bindparam(":documento", $documento);
			$stm->bindparam(":nombres", $nombres);
			$stm->bindparam(":Apellidos", $Apellidos);
			$stm->bindparam(":correo", $correo);
			$stm->bindparam(":clave", $clave);
			$stm->bindparam(":ProgramaFormacion", $ProgramaFormacion);
			$stm->bindparam(":ficha", $ficha);
			$stm->bindparam(":rol", $rol);

			if($stm->execute()) {
				return true;
			} else {
				return false;
			}
		} catch (PDOException $e) {
			echo $e->getMessage();
		} 
	}


	function modificarUsuario($con,  $TipoDocumento, $documento, $nombres, $Apellidos, $correo, $ProgramaFormacion, $ficha, $foto, $rol) {
		try {

			if($foto == null) {
				$sql = "UPDATE usuarios SET TipoDocumento = :TipoDocumento, documento = :documento, nombres = :nombres, Apellidos = :Apellidos, correo = :correo, ProgramaFormacion = :ProgramaFormacion, ficha = :ficha, foto = :foto, rol = :rol  WHERE documento = :documento";
			} else {
				$sql = "UPDATE usuarios SET TipoDocumento = :TipoDocumento, documento = :documento, nombres = :nombres, Apellidos = :Apellidos, correo = :correo, ProgramaFormacion = :ProgramaFormacion, ficha = :ficha, foto = :foto, rol = :rol  WHERE documento = :documento";
			}

			$stm = $con->prepare($sql);
			$stm->bindparam(":TipoDocumento", $TipoDocumento);
			$stm->bindparam(":documento", $documento);
			$stm->bindparam(":nombres", $nombres);
			$stm->bindparam(":Apellidos", $Apellidos);
			$stm->bindparam(":correo", $correo);
			$stm->bindparam(":ProgramaFormacion", $ProgramaFormacion);
			$stm->bindparam(":ficha", $ficha);
			if($foto != null) {
				$stm->bindparam(":foto", $foto);
			} 
			$stm->bindparam(":rol", $rol);
			if($stm->execute()) {
				return true;
			} else {
				return false;
			}
		} catch (PDOException $e) {
			echo $e->getMessage();
		} 
	}

	function eliminarUsuario($con, $documento) {
		try {
			$sql = "DELETE FROM usuarios WHERE documento = :documento";
			$stm = $con->prepare($sql);
			$stm->bindparam(":documento", $documento);
			if($stm->execute()) {
				return true;
			} else {
				return false;
			}
		} catch (PDOException $e) {
			echo $e->getMessage();
		} 
	}

	function eliminarUsuarioI($con, $documento) {
		try {
			$sql = "DELETE FROM instructores WHERE documento = :documento";
			$stm = $con->prepare($sql);
			$stm->bindparam(":documento", $documento);
			if($stm->execute()) {
				return true;
			} else {
				return false;
			}
		} catch (PDOException $e) {
			echo $e->getMessage();
		} 
	}

	function eliminarUsuarioA($con, $documento) {
		try {
			$sql = "DELETE FROM instructores WHERE documento = :documento";
			$stm = $con->prepare($sql);
			$stm->bindparam(":documento", $documento);
			if($stm->execute()) {
				return true;
			} else {
				return false;
			}
		} catch (PDOException $e) {
			echo $e->getMessage();
		} 
	}
	/* = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = 
	// test
	= = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = */

	function eliminarTest($con, $id) {
		try {
			$sql = "DELETE FROM usuarios WHERE documento = :id";
			$stm = $con->prepare($sql);
			$stm->bindparam(":id", $id);
			if($stm->execute()) {
				return true;
			} else {
				return false;
			}
		} catch (PDOException $e) {
			echo $e->getMessage();
		} 
	}

	function puntajeTest($con, $documento, $puntaje){
		try{
			$sql = "INSERT INTO testvelocidad (id, documento, puntaje) VALUES (DEFAULT, :documento, :puntaje)";

			$stm = $con->prepare($sql);
			$stm->bindparam(":documento", $documento);
			$stm->bindparam(":puntaje", $puntaje);

			if ($stm->execute()){
				return true;
			}else{
				return false;
			}
		}catch (Exception $e) {
			echo $e->getMessage();
		}
	}

	function puntajeTest2($con, $documento, $puntaje){
		try{
			$sql = "INSERT INTO testcomprension (id, documento, puntaje) VALUES (DEFAULT, :documento, :puntaje)";

			$stm = $con->prepare($sql);
			$stm->bindparam(":documento", $documento);
			$stm->bindparam(":puntaje", $puntaje);

			if ($stm->execute()){
				return true;
			}else{
				return false;
			}
		}catch (Exception $e) {
			echo $e->getMessage();
		}
	}

	function puntajeTest3($con, $documento, $puntaje){
		try{
			$sql = "INSERT INTO testrazonamiento (id, documento, puntaje) VALUES (DEFAULT, :documento, :puntaje)";

			$stm = $con->prepare($sql);
			$stm->bindparam(":documento", $documento);
			$stm->bindparam(":puntaje", $puntaje);

			if ($stm->execute()){
				return true;
			}else{
				return false;
			}
		}catch (Exception $e) {
			echo $e->getMessage();
		}
	}