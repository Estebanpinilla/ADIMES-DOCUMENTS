<?php include 'bd.php'; ?>


<?php 

	
	/* = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = 
	// Puntuacion
	= = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = */


  if($_GET){
    $documento =$_GET['documento'];
    $puntaje = $_GET['puntaje'];

   
    if (puntajeTest2($con, $documento, $puntaje)){
      echo "ok";
    }else{
      echo "notok";
    }

  }

 ?>