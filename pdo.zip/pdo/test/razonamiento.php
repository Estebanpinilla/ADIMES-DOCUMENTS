<?php require '../config/app.php'; ?>
<!-- <?php include '../config/security_apprentice.php'; ?> -->
<?php include '../config/bd.php'; ?>
<?php include '../includes/header.inc'; ?>
<?php include '../includes/navbar.inc'; ?>

<link rel="stylesheet" href="../public/css/bootstrap.min.css">
<link rel="stylesheet" href="../public/css/fontawesome-all.min.css">
<link rel="stylesheet" href="../public/css/custom.css">
<link rel="stylesheet" href="../public/css/owl.carousel.min.css">
<link rel="stylesheet" href="../public/css/owl.theme.default.min.css">
<link rel="stylesheet" href="../public/js/jquery-3.3.1.min.js">
<link rel="stylesheet" href="../public/js/jquery-ui.min.js">
<style>
	table{
		border-collapse: collapse;
		margin: 0px auto;
	}

	tr{
		border: 1px solid gray;
	}

	td{
		border: 1px solid gray;
	}
</style>

<!-- juego 1 -->
<h1 class="text-center"><i class="fa fa-cubes"></i> Razonamiento </h1>
<hr class="col-9 offset-1">
<div id="textDiv" style="font-size: 20px; text-align: center">  
	<div id="nested"></div>  
</div>
<div id="textRes" style="font-size: 20px; text-align: center">  
	<div id="nest"></div>  
</div> 
<div class="col-md-7 offset-9">
	<button class="btn btn-outline-primary w-25 siguiente" id="next"> Siguiente <i class="fa fa-arrow-right"></i></button>
</div>
<div class="col-md-7 offset-9">
	<a class="btn btn-outline-success w-25 oculta" id="back" href="test.php"><i class="fa fa-back"></i> Guardar </a>
</div>
<br>
<section style="font-family: calibri">
	<div class="primerj active">
		<table class="text-center table-hover">
			<thead>
				<tr>
					<th></th>
					<th></th>
					<th></th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td><img src="../public/imgs/razonamiento/f1.png" width="150" height="150"></td>
					<td><img src="../public/imgs/razonamiento/f2.png" width="150" height="150"></td>
					<td><img src="../public/imgs/razonamiento/f3.png" width="150" height="150"></td>

				</tr>
				<tr>
					<td colspan="3" class="bg-primary text-white">A. La cantidad de triángulos en la figura 4 sería: </td>
					
				</tr>
				<tr>
					<td><button class="btn btn-outline-primary w-50" name="boton1" type="button" id="boton1" value="boton 1" onclick="desactivar(this.name,'boton1,boton2,boton3)">15</button></td>
					<td><button class="btn btn-outline-primary w-50 correcta" name="boton2" type="button" id="boton2" value="boton 2" onclick="desactivar(this.name,'boton1,boton2,boton3)">16</button></td>
					<td><button class="btn btn-outline-primary w-50" name="boton3" type="button" id="boton3" value="boton 3" onclick="desactivar(this.name,'boton1,boton2,boton3)">17</button></td>
				</tr>
				<tr>
					<td colspan="3" class="bg-primary text-white">B. La cantidad de triángulos en la figura 5 sería: </td>
				</tr>
				<tr>
					<td><button class="btn btn-outline-primary w-50" name="boton4" type="button" id="boton4" value="boton 4" onclick="desactivar(this.name,'boton4,boton5,boton6)">24</button></td>
					<td><button class="btn btn-outline-primary w-50" name="boton5" type="button" id="boton5" value="boton 5" onclick="desactivar(this.name,'boton4,boton5,boton6)">27</button></td>
					<td><button class="btn btn-outline-primary w-50 correcta" name="boton6" type="button" id="boton6" value="boton 6" onclick="desactivar(this.name,'boton4,boton5,boton6)">25</button></td>
				</tr>
				<tr>
					<td colspan="3" class="bg-primary text-white">C. Qué figura tendría 25 triángulos.</td>
				</tr>
				<tr>
					<td><button class="btn btn-outline-primary w-50" name="boton7" type="button" id="boton7" value="boton 7" onclick="desactivar(this.name,'boton7,boton8,boton9)">figura 6</button></td>
					<td><button class="btn btn-outline-primary w-50 correcta" name="boton8" type="button" id="boton8" value="boton 8" onclick="desactivar(this.name,'boton7,boton8,boton9)">figura 5</button></td>
					<td><button class="btn btn-outline-primary w-50" name="boton9" type="button" id="boton9" value="boton 9" onclick="desactivar(this.name,'boton7,boton8,boton9)">figura 7</button></td>
				</tr>
			</tbody>
		</table>
	</div>

	<!-- juego 2 -->
	<div class="segundoj" style="height: 400px">
		<table class="text-center table-hover">
			<thead>
				<tr>
					<th></th>
					<th></th>
					<th></th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td><img src="../public/imgs/razonamiento/f4.png" width="170" height="150"></td>
					<td><img src="../public/imgs/razonamiento/f5.png" width="170" height="150"></td>
					<td><img src="../public/imgs/razonamiento/f6.png" width="170" height="150"></td>

				</tr>
				<tr>
					<td colspan="3" class="bg-success text-white">A. La cantidad de circulos en la figura 6 sería: </td>
					
				</tr>
				<tr>
					<td><button class="btn btn-outline-success w-50" name="boton10" type="button" id="boton10" value="boton 10" onclick="desactivar(this.name,'boton10,boton11,boton12)">16</button></td>
					<td><button class="btn btn-outline-success w-50" name="boton11" type="button" id="boton11" value="boton 11" onclick="desactivar(this.name,'boton10,boton11,boton12)">14</button></td>
					<td><button class="btn btn-outline-success w-50" name="boton12" type="button" id="boton12" value="boton 12" onclick="desactivar(this.name,'boton10,boton11,boton12)">15</button></td>
				</tr>
				<tr>
					<td colspan="3" class="bg-success text-white">B. La cantidad de circulos en la figura 8 sería: </td>
				</tr>
				<tr>
					<td><button class="btn btn-outline-success w-50" name="boton13" type="button" id="boton13" value="boton 13" onclick="desactivar(this.name,'boton13,boton14,boton15)">20</button></td>
					<td><button class="btn btn-outline-success w-50" name="boton14" type="button" id="boton14" value="boton 14" onclick="desactivar(this.name,'boton13,boton14,boton15)">22</button></td>
					<td><button class="btn btn-outline-success w-50" name="boton15" type="button" id="boton15" value="boton 15" onclick="desactivar(this.name,'boton13,boton14,boton15)">23</button></td>
				</tr>
				<tr>
					<td colspan="3" class="bg-success text-white">C. Qué figura tendría 28 circulos.</td>
				</tr>
				<tr>
					<td><button class="btn btn-outline-success w-50" name="boton16" type="button" id="boton16" value="boton 16" onclick="desactivar(this.name,'boton16,boton17,boton18)">figura 10</button></td>
					<td><button class="btn btn-outline-success w-50" name="boton17" type="button" id="boton17" value="boton 17" onclick="desactivar(this.name,'boton16,boton17,boton18)">figura 11</button></td>
					<td><button class="btn btn-outline-success w-50" name="boton18" type="button" id="boton18" value="boton 18" onclick="desactivar(this.name,'boton16,boton17,boton18)">figura 12</button></td>
				</tr>
			</tbody>
		</table>
	</div>

	<!-- juego 3 -->
	<div class="tercerj">
		<table class="text-center table-hover">
			<thead>
				<tr>
					<th></th>
					<th></th>
					<th></th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td colspan="4"><img class="text-center" src="../public/imgs/razonamiento/f7.png" width="550" height="150"></td>
				</tr>
				<tr>
					<td colspan="4" class="bg-danger text-white">A. La figura en el lugar 22 será:</td>
				</tr>
				<tr>
					<td><button class="btn btn-outline-danger w-75" name="boton19" type="button" id="boton19" value="boton 19" onclick="desactivar(this.name,'boton19,boton20,boton21,boton22)">Cuadro</button></td>
					<td><button class="btn btn-outline-danger w-75" name="boton20" type="button" id="boton20" value="boton 20" onclick="desactivar(this.name,'boton19,boton20,boton21,boton22)">Circulo</button></td>
					<td><button class="btn btn-outline-danger w-75" name="boton21" type="button" id="boton21" value="boton 21" onclick="desactivar(this.name,'boton19,boton20,boton21,boton22)">Tringulo</button></td>
					<td><button class="btn btn-outline-danger w-75" name="boton22" type="button" id="boton22" value="boton 22" onclick="desactivar(this.name,'boton19,boton20,boton21,boton22)">Rectangulo</button></td>
				</tr>
				<tr>
					<td colspan="4"><img src="../public/imgs/razonamiento/f8.png" width="750" height="150"></td>
				</tr>
				<tr>
					<td colspan="4" class="bg-success text-white">C. La figura en el lugar 22 será:</td>
				</tr>
				<tr>
					<td><button class="btn btn-outline-success w-75" name="boton23" type="button" id="boton23" value="boton 23" onclick="desactivar(this.name,'boton23,boton24,boton25,boton26)">Cuadrado Amarillo</button></td>
					<td><button class="btn btn-outline-success w-75" name="boton24" type="button" id="boton24" value="boton 24" onclick="desactivar(this.name,'boton23,boton24,boton25,boton26)">Rectangulo</button></td>
					<td><button class="btn btn-outline-success w-75" name="boton25" type="button" id="boton25" value="boton 25" onclick="desactivar(this.name,'boton23,boton24,boton25,boton26)">Triangulo</button></td>
					<td><button class="btn btn-outline-success w-75" name="boton26" type="button" id="boton26" value="boton 26" onclick="desactivar(this.name,'boton23,boton24,boton25,boton26)">Cuadrado Verde</button></td>

				</tr>
			</tbody>
		</table>
	</div>
</section>
<br><br> 	


<!--- cuadros/botones -->
<script src="../public/js/jquery-3.2.1.min.js"></script>
<script src="../public/js/jquery-ui.min.js"></script>
<script>
	// boton next
	function desactivar(name, nombreBotones){
		var partesBotones = nombreBotones.split(",");
		for (var i = 0; i<partesBotones.length; i++) {
			var boton = document.getElementById(partesBotones[i]);
			if (boton.name == name)boton.disabled = false;
			else boton.disabled = true;
		}
	}


	// -----------------------------respuestas-----------------------------------

	// boton2
	$(document).ready(function() {
		$("#boton2").click(function(event) {
			setTimeout(function() {
				$("#boton2").attr('disabled', 'disabled');
			}, 1000);

		});

		$("#alert")

		$veces = 1;

		$("#boton2").click(function(event) {
			$this = $(this);
			if ($veces <= 3) {
				$this.attr('disabled', 'disabled');
				$this.css('border', '4px solid red');
				$veces++;
			}	
		});
	});


	// boton6
	$(document).ready(function() {
		$("#boton6").click(function(event) {
			setTimeout(function() {
				$("#boton6").attr('disabled', 'disabled');
			}, 1000);

		});

		$("#alert")

		$veces = 1;

		$("#boton6").click(function(event) {
			$this = $(this);
			if ($veces <= 3) {
				$this.attr('disabled', 'disabled');
				$this.css('border', '4px solid red');
				$veces++;
			}	
		});
	});

	// boton8
	$(document).ready(function() {
		$("#boton8").click(function(event) {
			setTimeout(function() {
				$("#boton8").attr('disabled', 'disabled');
			}, 1000);

		});

		$("#alert")

		$veces = 1;

		$("#boton8").click(function(event) {
			$this = $(this);
			if ($veces <= 3) {
				$this.attr('disabled', 'disabled');
				$this.css('border', '4px solid red');
				$veces++;
			}	
		});
	});

	// boton10
	$(document).ready(function() {
		$("#boton10").click(function(event) {
			setTimeout(function() {
				$("#boton10").attr('disabled', 'disabled');
			}, 1000);

		});

		$("#alert")

		$veces = 1;

		$("#boton10").click(function(event) {
			$this = $(this);
			if ($veces <= 3) {
				$this.attr('disabled', 'disabled');
				$this.css('border', '4px solid red');
				$veces++;
			}	
		});
	});

	// boton14
	$(document).ready(function() {
		$("#boton14").click(function(event) {
			setTimeout(function() {
				$("#boton14").attr('disabled', 'disabled');
			}, 1000);

		});

		$("#alert")

		$veces = 1;

		$("#boton14").click(function(event) {
			$this = $(this);
			if ($veces <= 3) {
				$this.attr('disabled', 'disabled');
				$this.css('border', '4px solid red');
				$veces++;
			}	
		});
	});

	// boton16
	$(document).ready(function() {
		$("#boton16").click(function(event) {
			setTimeout(function() {
				$("#boton16").attr('disabled', 'disabled');
			}, 1000);

		});

		$("#alert")

		$veces = 1;

		$("#boton16").click(function(event) {
			$this = $(this);
			if ($veces <= 3) {
				$this.attr('disabled', 'disabled');
				$this.css('border', '4px solid red');
				$veces++;
			}	
		});
	});

	// boton19
	$(document).ready(function() {
		$("#boton19").click(function(event) {
			setTimeout(function() {
				$("#boton19").attr('disabled', 'disabled');
			}, 1000);

		});

		$("#alert")

		$veces = 1;

		$("#boton19").click(function(event) {
			$this = $(this);
			if ($veces <= 3) {
				$this.attr('disabled', 'disabled');
				$this.css('border', '4px solid red');
				$veces++;
			}	
		});
	});

	// boton24
	$(document).ready(function() {
		$("#boton24").click(function(event) {
			setTimeout(function() {
				$("#boton24").attr('disabled', 'disabled');
			}, 1000);

		});

		$("#alert")

		$veces = 1;

		$("#boton24").click(function(event) {
			$this = $(this);
			if ($veces <= 3) {
				$this.attr('disabled', 'disabled');
				$this.css('border', '4px solid red');
				$veces++;
			}	
		});
	});


	// next
	$('.segundoj, .tercerj').hide();

	$('#next').click(function() {
		$next = $('#next');
		$act = $('div.active');
		if($act.index() < 3) {
			$act.hide().removeClass('active');
			$act.next().fadeIn('slow').addClass('active');
		};
	});

	// puntaje
	$(document).ready(function() {
		$puntaje = 0;
		$('.correcta').click(function(event) {
			$puntaje += 12.5;

			$.get('../config/guardarr.php',{documento: <?php echo $_SESSION['udocumento']; ?>, puntaje: $puntaje}, function(data) {
				console.log(data);
			});

		});
	});
	
	// oculta siguiente activar salida
	$(document).ready(function() {
		$ccliks = 1;
		$oc = $('.oculta');

		$('.siguiente').click(function(event) {
			$('#ccliks').text($ccliks++);
			if ($ccliks == 3) {
				$('.siguiente').hide();
				$oc.show();
			} 
		});	
	});
	
	// tiempo
	var tiempo = 900;
	var oc = $('.oculta').hide();
	var sg = $('.siguiente').show();
	var si = setInterval(function(){
		if(tiempo == 0){
			$act = $('div.active');
			$fin = $('a#back');
			$nex = $('#next');
			$act.hide().removeClass('active');
			$fin.show().removeClass('.oculta');
			$nex.removeClass('.siguiente').hide();
			clearInteval(si);
		}

		var div = document.getElementById("textDiv");  
   		var nestedDiv = document.getElementById("nested");  
    	nestedDiv.textContent = tiempo;  

    	var text = "[" + div.textContent + "]";
		tiempo--;
	},1000);

	//validacion
	$(document).ready(function() {
		$cj = $('.cuartojuego');	
	});
</script>




