<?php require '../config/app.php'; ?>
<!-- <?php include '../config/security_apprentice.php'; ?> -->
<?php include '../config/bd.php'; ?>
<?php include '../includes/header.inc'; ?>
<?php include '../includes/navbar.inc'; ?>

<link rel="stylesheet" href="../public/css/bootstrap.min.css">
<link rel="stylesheet" href="../public/css/fontawesome-all.min.css">
<link rel="stylesheet" href="../public/css/custom.css">
<link rel="stylesheet" href="../public/css/owl.carousel.min.css">
<link rel="stylesheet" href="../public/css/owl.theme.default.min.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<!-- juego 1 -->
<div id="primerjuego" style="border: none">
	<h1 class="text-center"><i class="fa fa-cubes"></i> Memoria </h1>
	<hr id="ba" class="col-9">
	<div id="textDiv" style="font-size: 20px; text-align: center">  
		<div id="nested"></div>  
	</div>
	<div id="textRes" style="font-size: 20px; text-align: center">  
		<div id="nest"></div>  
	</div> 
	<br><br><br>
		<h3 id="t1">1. Concéntrate</h3>
		<div class="container">
			<div id="r2" class="row">
				<div class="col-md-11 offset-md-1 info">
					<p>A continuación encontrará un botón que al darle click mostrará tres imágenes las cuales tendrá que memorizar. Luego lea el texto. </p>
					
					<!-- Button trigger modal -->
					<button name="boton0" id="boton0" stype="button" class="btn btn-info" data-toggle="modal" data-target="#alert"><i class="fas fa-images"></i> Ver imágenes</button>

					<!-- Modal -->
					<div class="modal fade" id="alert" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
						<div class="modal-dialog" role="document">
							<div class="modal-content">
								<div class="modal-header">
									<h4 class="modal-title" id="exampleModalLabel"><strong>Memorizá las imágenes</strong></h4></button>
								</div>
								<div class="modal-body">
									<img src="../public/imgs/memoria/planetas.png" width="100%">
								</div>
								<div class="modal-footer">
									<button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
								</div>
							</div>
						</div>
					</div>

					<p class="p1">Es un conjunto de astros de la galaxia Vía Láctea formado por el Sol, nueve planetas, veintisiete satélites, muchos asteroides y cometas que giran todos alrededor del Sol. Los planetas son: Mercurio, Venus, la Tierra, Marte, Júpiter, Saturno, Urano, Neptuno y Plutón.

					El Sol es la estrella central del Sistema Solar. Tiene luz propia y nos da luz y calor a la Tierra y a todos los demás astros del Sistema. El Sol es la estrella fuente de toda vida en la Tierra. Sin el Sol no podríamos vivir. El Sol es mucho más grande la Tierra, tanto como 1.300.000, pero en realidad es una estrella pequeña. Casi todas las estrellas más brillantes que vemos por la noche en el cielo son más grandes que el Sol, pero al encontrarse tan alejadas de nosotros se perciben como simples puntos brillantes Las estrellas son los únicos cuerpos del Universo que emiten luz. </p>


				</div>
			<div class="col-md-7 offset-md-3 seleccionar">
				<p class="p2"><strong>Seleccione las tres imagenes que memorizó</strong> </p>
				<button name="boton1" type="button" id="boton1" value="boton1"  class="btn btn-outline-info boton">
					<img class="img" src="../public/imgs/memoria/correcta1.png" width="200" height="200" >
				</button>
				<button name="boton2" type="button" id="boton2" value="boton2"  class="btn btn-outline-info boton">
					<img class="img" src="../public/imgs/memoria/correcta2.png" width="200" height="200" alt="">
				</button>
				<button name="boton3" type="button" id="boton3" value="boton3"  class="btn btn-outline-info boton">
					<img class="img" src="../public/imgs/memoria/incorrecta1.png" width="200" height="200" alt="">
				</button>
				<button name="boton4" type="button" id="boton4" value="boton4"  class="btn btn-outline-info boton">
					<img class="img" src="../public/imgs/memoria/correcta3.png" width="200" height="200" alt="">
				</button>
				<button name="boton5" type="button" id="boton5" value="boton5"  class="btn btn-outline-info boton">
					<img class="img" src="../public/imgs/memoria/incorrecta2.png" width="200" height="200" alt="">
				</button>
				<button name="boton6" type="button" id="boton6" value="boton6"  class="btn btn-outline-info boton">
					<img class="img" src="../public/imgs/memoria/incorrecta3.png" width="200" height="200" alt="">
				</button>

			</div>

			<!-- Segunda pregunta-->
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="text-center recuerda">
							<h3 id="t2">2. Memorizar</h3>
							<p>A continuación encontrará 30 objetos que tendrás que memorizar para responder las preguntas.</p>
							
							<img src="../public/imgs/memoria/objeto3.png" style=" width: 500px; height: 500px; ">
							<br><br>
								
						</div>	
					</div>
				</div>
			</div>

			<div class="container">
				<div class="row">
					<div class="col-md-12 c1" style="margin-top: 100px">
							<div class="text-center">
									<p>Segun lo que memorizaste responde las siguientes preguntas</p>
									<p class="text-center">
										1. En la columna A3 ¿que imagen se encuentra?
									</p><br>
									<button class="btn btn-outline-primary w-10" name="boton1" id="boton1" type="button" value="Boton 1" onclick="desactivar(this.name,'boton1,boton2,boton3,boton4')"><img src="../public/imgs/memoria/abanico.png" alt=""></button>
									<button class="btn btn-outline-primary w-10" name="boton2" id="boton2" type="button" value="Boton 2" onclick="desactivar(this.name,'boton1,boton2,boton3,boton4')"><img src="../public/imgs/memoria/abanico.png" alt=""></button>
									<button class="btn btn-outline-primary w-10 correcta" name="boton3" id="boton3" type="button" value="Boton 3" onclick="desactivar(this.name,'boton1,boton2,boton3,boton4')"><img src="../public/imgs/memoria/abanico.png" alt=""></button>
									<button class="btn btn-outline-primary w-10"name="boton4" id="boton4" type="button" value="Boton 4" onclick="desactivar(this.name,'boton1,boton2,boton3,boton4')"><img src="../public/imgs/memoria/abanico.png" alt=""></button>
								</div>
								<br>
								<div class="text-center">
									<p class="text-center">
										2. En la columna C5 ¿que imagen se encuentra?
									</p><br>
									<button class="btn btn-outline-primary w-10" name="boton5" id="boton5" type="button" value="Boton 5" onclick="desactivar(this.name,'boton5,boton6,boton7,boton8')"><img src="../public/imgs/memoria/abanico.png" alt=""></button>
									<button class="btn btn-outline-primary w-10" name="boton6" id="boton6" type="button" value="Boton 6" onclick="desactivar(this.name,'boton5,boton6,boton7,boton8')"><img src="../public/imgs/memoria/abanico.png" alt=""></button>
									<button class="btn btn-outline-primary w-10 correcta" name="boton7" id="boton7" type="button" value="Boton 7" onclick="desactivar(this.name,'boton5,boton6,boton7,boton8')"><img src="../public/imgs/memoria/abanico.png" alt=""></button>
									<button class="btn btn-outline-primary w-10" name="boton8" id="boton8" type="button" value="Boton 8" onclick="desactivar(this.name,'boton5,boton6,boton7,boton8')"><img src="../public/imgs/memoria/abanico.png" alt=""></button>
								</div>
								<br>
							</div>
							<div class="preguntas2">
								<div class="text-center">
									<p class="text-center">
										3. En la columna D8 ¿que imagen se encuentra?
									</p>
									<br>
									<button class="btn btn-outline-primary w-10" name="boton9" id="boton9" type="button" value="Boton 9" onclick="desactivar(this.name,'boton9,boton10,boton11,boton12')"><img src="../public/imgs/memoria/abanico.png" alt=""></button>
									<button class="btn btn-outline-primary w-10 correcta" name="boton10" id="boton10" type="button" value="Boton 10" onclick="desactivar(this.name,'boton9,boton10,boton11,boton12')"><img src="../public/imgs/memoria/abanico.png" alt=""></button>
									<button class="btn btn-outline-primary w-10" name="boton11" id="boton11" type="button" value="Boton 11" onclick="desactivar(this.name,'boton9,boton10,boton11,boton12')"><img src="../public/imgs/memoria/abanico.png" alt=""></button>
									<button class="btn btn-outline-primary w-10" name="boton12" id="boton12" type="button" value="Boton 12" onclick="desactivar(this.name,'boton9,boton10,boton11,boton12')"><img src="../public/imgs/memoria/abanico.png" alt=""></button>
								</div>
								<br>
								<div class="text-center">
									<p class="text-center">
										4. En la columna  E5 ¿que imagen se encuentra? 
									</p>
									<button class="btn btn-outline-primary w-10" name="boton13" id="boton13" type="button" value="Boton 13" onclick="desactivar(this.name,'boton13,boton14,boton15,boton16')"><img src="../public/imgs/memoria/abanico.png" alt=""></button>
									<button class="btn btn-outline-primary w-10" name="boton14" id="boton14" type="button" value="Boton 14" onclick="desactivar(this.name,'boton13,boton14,boton15,boton16')"><img src="../public/imgs/memoria/abanico.png" alt=""></button>
									<button class="btn btn-outline-primary w-10 correcta" name="boton15" id="boton15" type="button" value="Boton 15" onclick="desactivar(this.name,'boton13,boton14,boton15,boton16')"><img src="../public/imgs/memoria/abanico.png" alt=""></button>
									<button class="btn btn-outline-primary w-10" name="boton16" id="boton16" type="button" value="Boton 16" onclick="desactivar(this.name,'boton13,boton14,boton15,boton16')"><img src="../public/imgs/memoria/abanico.png" alt=""></button>
								</div>
							</div> 	
					</div>
				</div>
			</div>
			<div class="col-md-7 offset-9">
				<button class="btn btn-outline-primary w-25 siguiente" id="next"> Siguiente <i class="fa fa-arrow-right"></i></button>
			</div>
			<div class="col-md-7 offset-9">
				<a class="btn btn-outline-success w-25 oculta" id="back" href="test.php"><i class="fa fa-back"></i> Salir </a>
			</div>
			<br><br><br><br>



			<!-- botones -->
			<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
			<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
			<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

			<script>
				//siguiente pregunta
				// $('.preguntas, .preguntas2, .preguntas3' ).hide();

				// $('#next').click(function() {
				// 	$next = $('#next');
				// 	$act = $('div.active');
				// 	if($act.index() < 3) {
				// 		$act.hide().removeClass('active');
				// 		$act.next().fadeIn('slow').addClass('active');
				// 	};
				// });

				// //siguiente->salir
				// $(document).ready(function() {
				// 	$ccliks = 1;
				// 	$oc = $('.oculta');

				// 	$('.siguiente').click(function(event) {
				// 		$('#ccliks').text($ccliks++);
				// 		if ($ccliks == 4) {
				// 			$('.siguiente').hide();
				// 			$oc.show();
				// 		} 
				// 	});	
				// });

				// tiempo
				var tiempo = 900;
				var oc = $('.oculta').hide();
				var sg = $('.siguiente').show();
				var si = setInterval(function(){
					if(tiempo == 0){
						$act = $('div.active');
						$fin = $('a#back');
						$nex = $('#next');
						$act.hide().removeClass('active');
						$fin.show().removeClass('.oculta');
						$nex.removeClass('.siguiente').hide();
						clearInteval(si);
					}

					var div = document.getElementById("textDiv");  
					var nestedDiv = document.getElementById("nested");  
					nestedDiv.textContent = tiempo;  

					var text = "[" + div.textContent + "]";
					tiempo--;
				},1000);
							// Preguntas
							$(document).ready(function() {
								$("#boton0").click(function(event) {
									setTimeout(function() {
										$("#boton0").attr('disabled', 'disabled');
									}, 1000);

								});

								$("#alert")

								$veces = 1;

								$(".boton").click(function(event) {
									$this = $(this);
									if ($veces <= 3) {
										$this.attr('disabled', 'disabled');
										$this.css('border', '4px solid red');
										$veces++;
									}	

								});
							});

						    function desactivar(name, nombreBotones){
		var partesBotones = nombreBotones.split(",");
		for (var i = 0; i<partesBotones.length; i++) {
			var boton = document.getElementById(partesBotones[i]);
			if (boton.name == name)boton.disabled = false;
			else boton.disabled = true;
		}
	}


	// boton 3
	$(document).ready(function() {
		$("#boton3").click(function(event) {
			setTimeout(function() {
				$("#boton3").attr('disabled', 'disabled');
			}, 1000);

		});

		$("#alert")

		$veces = 1;

		$("#boton3").click(function(event) {
			$this = $(this);
			if ($veces <= 3) {
				$this.attr('disabled', 'disabled');
				$this.css('border', '4px solid green');
				$veces++;
			}	
		});
	});

	// boton 7
	$(document).ready(function() {
		$("#boton7").click(function(event) {
			setTimeout(function() {
				$("#boton7").attr('disabled', 'disabled');
			}, 1000);

		});

		$("#alert")

		$veces = 1;

		$("#boton7").click(function(event) {
			$this = $(this);
			if ($veces <= 3) {
				$this.attr('disabled', 'disabled');
				$this.css('border', '4px solid green');
				$veces++;
			}	
		});
	});

	// boton 10
	$(document).ready(function() {
		$("#boton10").click(function(event) {
			setTimeout(function() {
				$("#boton10").attr('disabled', 'disabled');
			}, 1000);

		});

		$("#alert")

		$veces = 1;

		$("#boton10").click(function(event) {
			$this = $(this);
			if ($veces <= 3) {
				$this.attr('disabled', 'disabled');
				$this.css('border', '4px solid green');
				$veces++;
			}	
		});
	});

	// boton 15
	$(document).ready(function() {
		$("#boton15").click(function(event) {
			setTimeout(function() {
				$("#boton15").attr('disabled', 'disabled');
			}, 1000);

		});

		$("#alert")

		$veces = 1;

		$("#boton15").click(function(event) {
			$this = $(this);
			if ($veces <= 3) {
				$this.attr('disabled', 'disabled');
				$this.css('border', '4px solid green');
				$veces++;
			}	
		});
	});

	// boton 17
	$(document).ready(function() {
		$("#boton17").click(function(event) {
			setTimeout(function() {
				$("#boton17").attr('disabled', 'disabled');
			}, 1000);

		});

		$("#alert")

		$veces = 1;

		$("#boton17").click(function(event) {
			$this = $(this);
			if ($veces <= 3) {
				$this.attr('disabled', 'disabled');
				$this.css('border', '4px solid green');
				$veces++;
			}	
		});
	});

	// boton 23
	$(document).ready(function() {
		$("#boton23").click(function(event) {
			setTimeout(function() {
				$("#boton23").attr('disabled', 'disabled');
			}, 1000);

		});

		$("#alert")

		$veces = 1;

		$("#boton23").click(function(event) {
			$this = $(this);
			if ($veces <= 3) {
				$this.attr('disabled', 'disabled');
				$this.css('border', '4px solid green');
				$veces++;
			}	
		});
	});
			</script>
