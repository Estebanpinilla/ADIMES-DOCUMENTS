<?php require '../config/app.php'; ?>
<!-- <?php include '../config/security_apprentice.php'; ?> -->
<?php include '../config/bd.php'; ?>
<?php include '../includes/header.inc'; ?>
<?php include '../includes/navbar.inc'; ?>

<link rel="stylesheet" href="../public/css/bootstrap.min.css">
<link rel="stylesheet" href="../public/css/fontawesome-all.min.css">
<link rel="stylesheet" href="../public/css/custom.css">
<link rel="stylesheet" href="../public/css/owl.carousel.min.css">
<link rel="stylesheet" href="../public/css/owl.theme.default.min.css">
<link rel="stylesheet" href="../public/js/jquery-3.3.1.min.js">
<link rel="stylesheet" href="../public/js/jquery-ui.min.js">


<h1 class="text-center">Comprensión</h1>
<hr>
<div id="textDiv" style="font-size: 20px; text-align: center">  
	<div id="nested"></div>  
</div>
<div id="textRes" style="font-size: 20px; text-align: center">  
	<div id="nest"></div>  
</div> 
<div class="col-md-7 offset-9">
	<button class="btn btn-outline-primary w-25 siguiente" id="next"> Siguiente <i class="fa fa-arrow-right"></i></button>
</div>
<div class="col-md-7 offset-9">
	<a class="btn btn-outline-success w-25 oculta" id="back" href="test.php"><i class="fa fa-back"></i> Salir </a>
</div>
<br><br><br><br>
<div class="container">
	<div class="row text-justify">
		<div class="col-md-8 offset-2">
			<div class="explicacion active">
				<p>
					<h3 class="text-center">El pensamiento sobre el Hombre.</h3>   

					En el mundo occidental , griegos y romanos, comenzaron a preguntarse sobre el origen del hombre y las sociedades, al mismo tiempo que el paradigma exploratorio y la necesidad de descubrir al “Otro“ en sus límites culturales y geográficos, alimentaban la esperanza de un mundo desconocido y abundante en diversidad.

					Los relatos de  grandes viajeros como Jenófanes, Herodoto o el propio Alejandro Magno, junto con la mitología, la política, la biología y otras áreas del conocimiento contribuyeron a la profunda reflexión sobre el origen del hombre, la sociedad y las diferencias entre unos pueblos y otros.

					Los sofistas trataron de dar una explicación práctica al surgimiento de las sociedades, Sócrates y Platón propusieron la ética y los valores universales como explicación a esos fenómenos comunes en todos los pueblos, Aristóteles apostó por la biología haciendo de la sociedad y la cultura una carga inherente al ser humano. Epicúreos y estoicos centraron el origen social en el individuo y en su necesidad de bienestar. 

					De esta primera experiencia sobre el debate antropológico podemos extraer una referencia  que va a marcar de manera  general la evolución de los estudios sobre las sociedades y las culturas: al hombre le satisface pensar  sobre sí mismo y además este pensamiento es la clave que encamina a la resolución de algunos problemas de convivencia. 

					“Chatos, negros: así ven los etíopes a sus dioses. De ojos azules y rubios: así ven a sus dioses los tracios. Pero si los bueyes y los caballos y los leones tuvieran manos como las personas, para dibujar, para pintar, para crear una obra de arte, entonces los caballos pintarían a los dioses semejantes a los caballos, los bueyes semejantes a bueyes, y a partir de sus figuras crearían las formas de los cuerpos divinos según su propia imagen: cada uno según la suya “(Jenófanes de Colofón 550-475 a.C.)

					“ El ser humano es un ser social por naturaleza, y el insocial por naturaleza y no por azar o es mal humano o más que humano…el que no puede vivir en sociedad, o no necesita nada por su propia suficiencia, no es miembro de la sociedad sino una bestia o un dios “ ( Aristóteles 384-322 a.C.)
					“Con perfecto derecho los españoles ejercen su dominio sobre estos bárbaros del Nuevo Mundo e islas adyacentes, los cuales en prudencia, ingenio y todo género de virtudes y humanos sentimientos son tan inferiores a los españoles como los niños a los adultos, las mujeres a los varones, como gentes crueles e inhumanos a muy mansos, exageradamente intemperantes a continentes y moderados, finalmente estoy por decir, cuanto los monos a los hombres “ (Fray Ginés de Sepúlveda. XVI)

					“El alma humana es cierta sustancia; más no sustancia universal. Luego es sustancia particular, y por consiguiente hipóstasi o persona, y precisamente humana. Luego el alma es el hombre, pues la persona humana es el hombre “(Santo Tomás de Aquino)
					
					<br><br>
					<h4>Del estudio del hombre al encuentro con las culturas.</h4> 

					A pesar de que el teocentrismo impregnaba muchos debates en relación con el hombre, privado de su papel como actor social, la Edad Media supuso la apertura del pensamiento sobre  el origen de la sociedad y el papel de la Iglesia en estos asuntos.

					Con el redescubrimiento de Aristóteles en el siglo XII, aparece  el hombre como ser dotado de razón, capaz de mejorar su propio destino y su condición social. Estas ideas crecieron en la obra de Santo Tomás de Aquino, quien  llegó a la conclusión de que el hombre se situaba en un escalón inmediatamente inferior al de los ángeles.  Sostuvo además la unidad psíquica del hombre,”por naturaleza todos los hombres son iguales“ otro de los paradigmas sobre los que la sociedad y en especial los gobiernos han interrogado a la antropología, especialmente en situaciones relacionadas con la esclavitud, el abuso de poder,  la emancipación de la mujer,…
				</p>
			</div>
			<div class="preguntas">
				<div class="text-center">
					<h3 class="text-center">Con base en el texto responde las siguientes preguntas</h3>
					<p class="text-left">
						1.  En el mundo occidental_________________ comenzaron a preguntarse sobre el origen del hombre y las sociedades.
					</p>
					<button class="btn btn-outline-primary w-50" name="boton1" id="boton1" type="button" value="Boton 1" onclick="desactivar(this.name,'boton1,boton2,boton3,boton4')">griegos y etruscos</button>
					<button class="btn btn-outline-primary w-50" name="boton2" id="boton2" type="button" value="Boton 2" onclick="desactivar(this.name,'boton1,boton2,boton3,boton4')">romanos y etruscos</button>
					<button class="btn btn-outline-primary w-50 correcta" name="boton3" id="boton3" type="button" value="Boton 3" onclick="desactivar(this.name,'boton1,boton2,boton3,boton4')">griegos y romanos</button>
					<button class="btn btn-outline-primary w-50"name="boton4" id="boton4" type="button" value="Boton 4" onclick="desactivar(this.name,'boton1,boton2,boton3,boton4')">romanos y helenos</button>
				</div>
				<div class="text-center">
					<p class="text-left">
						2. Los relatos de grandes viajeros como _____________, Herodoto :
					</p>
					<button class="btn btn-outline-primary w-50" name="boton5" id="boton5" type="button" value="Boton 5" onclick="desactivar(this.name,'boton5,boton6,boton7,boton8')">Tebas</button>
					<button class="btn btn-outline-primary w-50" name="boton6" id="boton6" type="button" value="Boton 6" onclick="desactivar(this.name,'boton5,boton6,boton7,boton8')">Simonides</button>
					<button class="btn btn-outline-primary w-50 correcta" name="boton7" id="boton7" type="button" value="Boton 7" onclick="desactivar(this.name,'boton5,boton6,boton7,boton8')">Jenófanes</button>
					<button class="btn btn-outline-primary w-50" name="boton8" id="boton8" type="button" value="Boton 8" onclick="desactivar(this.name,'boton5,boton6,boton7,boton8')">Platón</button>
				</div>
			</div>
			<div class="preguntas2">
				<div class="text-center">
					<p class="text-left">
						3.  ____________ apostó por la biología haciendo de la sociedad y la cultura una carga inherente al ser humano.:
					</p>
					<button class="btn btn-outline-primary w-50" name="boton9" id="boton9" type="button" value="Boton 9" onclick="desactivar(this.name,'boton9,boton10,boton11,boton12')">Sócrates</button>
					<button class="btn btn-outline-primary w-50 correcta" name="boton10" id="boton10" type="button" value="Boton 10" onclick="desactivar(this.name,'boton9,boton10,boton11,boton12')">Aristóteles</button>
					<button class="btn btn-outline-primary w-50" name="boton11" id="boton11" type="button" value="Boton 11" onclick="desactivar(this.name,'boton9,boton10,boton11,boton12')">Platón</button>
					<button class="btn btn-outline-primary w-50" name="boton12" id="boton12" type="button" value="Boton 12" onclick="desactivar(this.name,'boton9,boton10,boton11,boton12')">Nemon</button>
				</div>
				<div class="text-center">
					<p class="text-left">
						4. al hombre le satisface pensar sobre ____________ y además este pensamiento es la clave que encamina a la resolución de algunos problemas de convivencia. 
					</p>
					<button class="btn btn-outline-primary w-50" name="boton13" id="boton13" type="button" value="Boton 13" onclick="desactivar(this.name,'boton13,boton14,boton15,boton16')">Lo que le rodea</button>
					<button class="btn btn-outline-primary w-50" name="boton14" id="boton14" type="button" value="Boton 14" onclick="desactivar(this.name,'boton13,boton14,boton15,boton16')">El universo </button>
					<button class="btn btn-outline-primary w-50 correcta" name="boton15" id="boton15" type="button" value="Boton 15" onclick="desactivar(this.name,'boton13,boton14,boton15,boton16')">Sí mismo</button>
					<button class="btn btn-outline-primary w-50" name="boton16" id="boton16" type="button" value="Boton 16" onclick="desactivar(this.name,'boton13,boton14,boton15,boton16')">La antropología</button>
				</div>
			</div>
			<div class="preguntas3">
				<div class="text-center">
					<p class="text-left">
						5. El alma humana es cierta sustancia; más no sustancia universal. Luego es sustancia particular, y por consiguiente hipóstasi o persona, y precisamente humana. Luego el alma es el hombre, pues la persona humana es el hombre “ 
					</p>
					<button class="btn btn-outline-primary w-50 correcta" name="boton17" id="boton17" type="button" value="Boton 17" onclick="desactivar(this.name,'boton17,boton18,boton19,boton20')">Santo Tomás de Aquino</button>
					<button class="btn btn-outline-primary w-50" name="boton18" id="boton18" type="button" value="Boton 18" onclick="desactivar(this.name,'boton17,boton18,boton19,boton20')">Fray Ginés de Sepúlveda</button>
					<button class="btn btn-outline-primary w-50" name="boton19" id="boton19" type="button" value="Boton 19" onclick="desactivar(this.name,'boton17,boton18,boton19,boton20')">Jenófanes de Colofón</button>
					<button class="btn btn-outline-primary w-50" name="boton20" id="boton20" type="button" value="Boton 20" onclick="desactivar(this.name,'boton17,boton18,boton19,boton20')">Santo Tomás de Villanueva</button>
				</div>
				<div class="text-center">
					<p class="text-left">
						6. A pesar de que el ______________ impregnaba muchos debates en relación con el hombre, privado de su papel como actor social, la Edad Media supuso la apertura del pensamiento sobre el origen de la sociedad y el papel de la Iglesia en estos asuntos.  
					</p>
					<button class="btn btn-outline-primary w-50" name="boton21" id="boton21" type="button" value="Boton 21" onclick="desactivar(this.name,'boton21,boton22,boton23,boton24')">Misticismo</button>
					<button class="btn btn-outline-primary w-50" name="boton22" id="boton22" type="button" value="Boton 22" onclick="desactivar(this.name,'boton21,boton22,boton23,boton24')">Geocentrismo</button>
					<button class="btn btn-outline-primary w-50 correcta" name="boton23" id="boton23" type="button" value="Boton 23" onclick="desactivar(this.name,'boton21,boton22,boton23,boton24')">Teocentrismo</button>
					<button class="btn btn-outline-primary w-50" name="boton24" id="boton24" type="button" value="Boton 24" onclick="desactivar(this.name,'boton21,boton22,boton23,boton24')">Humanismo</button>
				</div>
			</div>
		</div>
	</div>
</div>
</div>

<script src="../public/js/jquery-3.2.1.min.js"></script>
<script src="../public/js/jquery-ui.min.js"></script>
<script>
	//siguiente pregunta
	$('.preguntas, .preguntas2, .preguntas3' ).hide();

	$('#next').click(function() {
		$next = $('#next');
		$act = $('div.active');
		if($act.index() < 3) {
			$act.hide().removeClass('active');
			$act.next().fadeIn('slow').addClass('active');
		};
	});

	//siguiente->salir
	$(document).ready(function() {
		$ccliks = 1;
		$oc = $('.oculta');

		$('.siguiente').click(function(event) {
			$('#ccliks').text($ccliks++);
			if ($ccliks == 4) {
				$('.siguiente').hide();
				$oc.show();
			} 
		});	
	});

	// tiempo
	var tiempo = 900;
	var oc = $('.oculta').hide();
	var sg = $('.siguiente').show();
	var si = setInterval(function(){
		if(tiempo == 0){
			$act = $('div.active');
			$fin = $('a#back');
			$nex = $('#next');
			$act.hide().removeClass('active');
			$fin.show().removeClass('.oculta');
			$nex.removeClass('.siguiente').hide();
			clearInteval(si);
		}

		var div = document.getElementById("textDiv");  
		var nestedDiv = document.getElementById("nested");  
		nestedDiv.textContent = tiempo;  

		var text = "[" + div.textContent + "]";
		tiempo--;
	},1000);

	//validacion
	$(document).ready(function() {
		$cj = $('.cuartojuego');	
	});

	//puntaje
	$(document).ready(function() {
		$puntaje = 0;
		$('.correcta').click(function(event) {
			$puntaje += 16.6;

			$.get('../config/guardarc.php',{documento: <?php echo $_SESSION['udocumento']; ?>, puntaje: $puntaje}, function(data) {
				console.log(data);
			});

		});
	});
	// -------------------------respuestas---------------------------------

	function desactivar(name, nombreBotones){
		var partesBotones = nombreBotones.split(",");
		for (var i = 0; i<partesBotones.length; i++) {
			var boton = document.getElementById(partesBotones[i]);
			if (boton.name == name)boton.disabled = false;
			else boton.disabled = true;
		}
	}


	// boton 3
	$(document).ready(function() {
		$("#boton3").click(function(event) {
			setTimeout(function() {
				$("#boton3").attr('disabled', 'disabled');
			}, 1000);

		});

		$("#alert")

		$veces = 1;

		$("#boton3").click(function(event) {
			$this = $(this);
			if ($veces <= 3) {
				$this.attr('disabled', 'disabled');
				$this.css('border', '4px solid green');
				$veces++;
			}	
		});
	});

	// boton 7
	$(document).ready(function() {
		$("#boton7").click(function(event) {
			setTimeout(function() {
				$("#boton7").attr('disabled', 'disabled');
			}, 1000);

		});

		$("#alert")

		$veces = 1;

		$("#boton7").click(function(event) {
			$this = $(this);
			if ($veces <= 3) {
				$this.attr('disabled', 'disabled');
				$this.css('border', '4px solid green');
				$veces++;
			}	
		});
	});

	// boton 10
	$(document).ready(function() {
		$("#boton10").click(function(event) {
			setTimeout(function() {
				$("#boton10").attr('disabled', 'disabled');
			}, 1000);

		});

		$("#alert")

		$veces = 1;

		$("#boton10").click(function(event) {
			$this = $(this);
			if ($veces <= 3) {
				$this.attr('disabled', 'disabled');
				$this.css('border', '4px solid green');
				$veces++;
			}	
		});
	});

	// boton 15
	$(document).ready(function() {
		$("#boton15").click(function(event) {
			setTimeout(function() {
				$("#boton15").attr('disabled', 'disabled');
			}, 1000);

		});

		$("#alert")

		$veces = 1;

		$("#boton15").click(function(event) {
			$this = $(this);
			if ($veces <= 3) {
				$this.attr('disabled', 'disabled');
				$this.css('border', '4px solid green');
				$veces++;
			}	
		});
	});

	// boton 17
	$(document).ready(function() {
		$("#boton17").click(function(event) {
			setTimeout(function() {
				$("#boton17").attr('disabled', 'disabled');
			}, 1000);

		});

		$("#alert")

		$veces = 1;

		$("#boton17").click(function(event) {
			$this = $(this);
			if ($veces <= 3) {
				$this.attr('disabled', 'disabled');
				$this.css('border', '4px solid green');
				$veces++;
			}	
		});
	});

	// boton 23
	$(document).ready(function() {
		$("#boton23").click(function(event) {
			setTimeout(function() {
				$("#boton23").attr('disabled', 'disabled');
			}, 1000);

		});

		$("#alert")

		$veces = 1;

		$("#boton23").click(function(event) {
			$this = $(this);
			if ($veces <= 3) {
				$this.attr('disabled', 'disabled');
				$this.css('border', '4px solid green');
				$veces++;
			}	
		});
	});
</script>