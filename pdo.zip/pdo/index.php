<?php require 'config/app.php'; ?>
<?php include 'config/redirect.php'; ?>
<?php include 'config/bd.php'; ?>
<?php include 'includes/header.inc'; ?>

<link rel="stylesheet" href="../public/css/bootstrap.min.css">
<link rel="stylesheet" href="../public/css/custom.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">

<div class="container">
	<div class="row">
		<div class="col-md-8 offset-md-2">
			<?php include 'pages/home.php'; ?>
		</div>
	</div>
</div>
<?php $con = null; ?>
<?php include 'includes/footer.inc'; ?> 
