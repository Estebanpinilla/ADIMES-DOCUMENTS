<?php require '../config/app.php'; ?>
<?php include '../config/bd.php'; ?>
<?php include '../config/security_instructor.php'; ?>
<?php include '../includes/header.inc'; ?>
<?php include '../includes/navbar.inc'; ?>

<link rel="stylesheet" href="../public/css/bootstrap.min.css">
<link rel="stylesheet" href="../public/css/fontawesome-all.min.css">
<link rel="stylesheet" href="../public/css/custom.css">
<link rel="stylesheet" href="../public/css/owl.carousel.min.css">
<link rel="stylesheet" href="../public/css/owl.theme.default.min.css">
<br><br>
<div class="container">
	<div class="row">
		<div class="col-md-6 offset-md-3">
			<h1 class="text-center text-muted my-5"> <i class="fa fa-user"></i> Bienvenido Instructor </h1>
			<hr>
			<table class="table table-bordered table-hover">
				<thead class="text-center gbt">
					<th colspan="2">Funcionalidad</th>
				</thead>
				<tbody>
					<tr>
						<td colspan="2">
							A continuación encontrará dos opciones donde podrá gestionar los siguientes módulos. La primera opción es para gestionar usuarios y en la segunda opción podrá realizar gestión de los test implementados en el sistema de información
						</td>
					</tr>
					<tr>
						<td class="text-center gbt"><strong>Módulo Usuarios</strong></td>
						<td class="text-center gbt"><strong>Módulo Test</strong></td>
					</tr>
					<tr>
						<td class="text-center">
							<a href="../users/" class="btn btn-outline-success btn-lg">
								<i class="fa fa-users"></i>
								Gestionar 
							</a>
						</td>
						<td class="text-center">
							<a href="../metodologias/metodologias.php" class="btn btn-outline-success btn-lg">
								<i class="fa fa-list"></i>
								Gestionar
							</a>
						</td>
					</tr>
				</tbody>
			</table>
			<div class="instituciones text-center">
				<h3>Instituciones de Apoyo</h3>
				<hr class="col-9">
				<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
					<ol class="carousel-indicators">
						<li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
						<li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
						<li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
					</ol>
					<div class="carousel-inner" role="listbox">
						<div class="carousel-item active">
							<a href="https://goo.gl/m30aRd"><img class="d-block img-fluid" src="../public/imgs/logos/biblioteca.jpg" alt="First slide"></a>
						</div>
						<div class="carousel-item">
							<a href="https://goo.gl/qgXA2V"><img class="d-block img-fluid" src="../public/imgs/logos/bienestar.jpg" alt="Second slide"></a>
						</div>
						<div class="carousel-item">
							<a href="https://goo.gl/dKhN4n"><img class="d-block img-fluid" src="../public/imgs/logos/ministerio.png" alt="Third slide"></a>
						</div>
					</div>
					<a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
						<span class="carousel-control-prev-icon btn" aria-hidden="true" style="background-color: black; border-radius: 50%;"></span>
						<span class="sr-only">Previous</span>
					</a>
					<a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
						<span class="carousel-control-next-icon btn" aria-hidden="true" style="background-color: black; border-radius: 50%;"></span>
						<span class="sr-only">Next</span>
					</a>
				</div>
			</div>
		</div>
	</div>
</div>
<br><br><br><br><br>
<?php $con = null; ?>
<?php include '../includes/footer.inc'; ?>