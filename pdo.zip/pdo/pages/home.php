 <?php 
 if ($_POST) {
  $documento = $_POST['documento'];
  $clave  = md5($_POST['clave']);
  if(login($con, $documento, $clave)) {
          // $_SESSION['type']    = 'success';
          // $_SESSION['message'] = 'Los datos del Usuario son Correctos!';
    if($_SESSION['urol'] == 'Aprendiz') {
      echo "<script> window.location.replace('pages/apprentice.php'); </script>";
    } else if($_SESSION['urol'] == 'Instructor') {
      echo "<script> window.location.replace('pages/instructor.php'); </script>";
    } else if($_SESSION['urol'] == 'Admin') {
      echo "<script> window.location.replace('pages/administrator.php'); </script>";
    }
  } else {
    $_SESSION['type']    = 'danger';
    $_SESSION['message'] = 'Los datos del Usuario son Incorrectos!';
  }
}

?>


<link rel="stylesheet" href="sweetalert2.min.css" >
<link rel="stylesheet" href="../public/css/bootstrap.min.css">
<link rel="stylesheet" href="../public/css/custom.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">

<body class="presentacion">
  <div class="col-md-12 offset-2">
    <div class="logosinfo">
      <h4>Conócete, Aprende y Juega</h4>
      <br><br>
      <p>
        SENA Regional Caldas<br><br><br>   
        Centro de Procesos Industriales y Construcción <br><br><br>
        Bienestar al Aprendiz <br><br><br>
        Diego Ángelo Restrepo Zapata <br>
      </p>
      <br><br><br><br>
      <img src="public/imgs/logos/logos.png" alt="" width="290px">
    </div>  
    <div id="home" class="container" style="margin-bottom: 50px; margin-top: 200px">
      <div class="row">
        <div class="col-md-5 offset-1">
          <div class="formulario">
            <fieldset class="formulario2"> 
              <img src="public/imgs/logos/nofoto.png" class="my-5" width="100px" height="100px" style="border-radius: 50%">
              <form action="" method="post">
                <div class="form-group col-md-6 offset-md-3">
                  <input type="number" class="form-control" name="documento" placeholder="Numero de documento">
                </div>
                <div class="form-group col-md-6 offset-md-3">
                  <input type="password" class="form-control" name="clave" placeholder="Contraseña">
                </div>
                <div class="form-group">
                  <button type="submit" class="btn bgf w-25" style="color: white"> <i class="fa fa-sign-in-alt">  
                  </i> Ingresar </button>
                </div>
                <div>
                  <button type="button" class="btn bgf w-25" data-toggle="modal" data-target="#exampleModalCenter" style="color: white">Registro
                  </button><br>
                </div>
              </form>
            </div>
          </fieldset>
        </div>
      </div>


      <!-- Modal -->
      <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
          <div class="modal-content">
            <div class="modal-header bgf">
              <h5 class="modal-title text-white Hand" id="exampleModalLongTitle">Registro</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <!-- multistep form -->
              <form  action="" id="msform" method="post" enctype="multipart/form-data">
                <!-- fieldsets -->
                <fieldset class="active">
                  <h2 class="fs-title">Crea tu perfil</h2>
                  <h3 class="fs-subtitle">Paso 1</h3>
                  <select name="TipoDocumento" class="custom-select" style="margin-bottom: 10px">
                    <option value="">Tipo Documento...</option>
                    <option value="TI" <?php if(['TipoDocumento'] == "TI") echo "selected"; ?> >Tarjeta Identidad</option>
                    <option value="CC" <?php if(['TipoDocumento'] == "CC") echo "selected"; ?> >Cedula Ciudadania</option>
                    <option value="CE" <?php if(['TipoDocumento'] == "CE") echo "selected"; ?> >Cedula Extranjera</option>
                  </select>
                  <input type="number" class="form-control" name="documento" placeholder="Documento de identidad" required>
                  <input type="text" class="form-control" name="nombres" placeholder="Nombre" required>
                  <input type="text" class="form-control" name="Apellidos" placeholder="Apellidos" required>
                  <input type="button" name="next" class="next action-button" value="Next" />
                </fieldset>
                <fieldset>
                  <h2 class="fs-title">Curso</h2>
                  <h3 class="fs-subtitle">Paso 2</h3>
                  <input type="text" class="form-control" name="ProgramaFormacion"  placeholder="Programa Formacion" required>
                  <input type="number" class="form-control" name="ficha" placeholder="ficha" required>
                  <input type="button" name="next" class="next action-button" value="Next" />
                </fieldset>
                <fieldset>
                  <h2 class="fs-title">Informacion Adicional</h2>
                  <h3 class="fs-subtitle">Paso 3</h3>
                  <input type="email" class="form-control" name="correo" placeholder="Correo Electronico" required>
                  <input type="password" class="form-control" name="clave" placeholder="Contraseña" required>
                  <select name="rol" class="custom-select" style="margin-bottom: 10px">
                    <option value="">Rol</option>
                    <option value="Aprendiz" <?php if(['rol'] == "Aprendiz") echo "selected"; ?> >Aprendiz</option>
                  </select>
                  <input type="submit" name="submit" class="submit action-button" value="Submit" />
                </fieldset>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </body>

  <?php 
  if($_POST){
    $TipoDocumento =$_POST['TipoDocumento'];
    $documento =$_POST['documento'];
    $nombres =$_POST['nombres'];
    $Apellidos =$_POST['Apellidos'];
    $correo =$_POST['correo'];
    $clave =md5($_POST['clave']);
    $ProgramaFormacion =$_POST['ProgramaFormacion'];
    $ficha =$_POST['ficha'];
    $rol =$_POST['rol'];

    registrarUsuarioA($con, $TipoDocumento, $documento, $nombres, $Apellidos, $correo, $clave, $ProgramaFormacion, $ficha, $rol);
    if (registrarUsuario($con, $TipoDocumento, $documento, $nombres, $Apellidos, $correo, $clave, $ProgramaFormacion, $ficha, $rol)){
      $_SESSION['type'] = 'success';
      $_SESSION['message'] = 'EL usuario  se Adiciono Correctamente';
    }else{
      $_SESSION['type'] = 'danger';
      $_SESSION['message'] = 'EL usuario no se Adiciono Correctamente';
    }

  }


  ?>
  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js" integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous"></script>
  <script src="../public/js/bootstrap.min.js"></script>
  <script src="../public/js/sweetalert2.all.js"></script>
  <script src ="sweetalert2.min.js"> </script>
  <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js" ></script>
  <script src="//cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>
  <script>
    $('.fm2, .fm3').hide();

    $('.next').click(function() {
      $act = $('fieldset.active');
      if($act.index() < 3) {
        $act.hide().removeClass('active');
        $act.next().fadeIn('slow').addClass('active');
      }
      ;
    });

  </script>
  <script>
//jQuery time
var current_fs, next_fs, previous_fs; //fieldsets
var left, opacity, scale; //fieldset properties which we will animate
var animating; //flag to prevent quick multi-click glitches

$(".next").click(function(){
  if(animating) return false;
  animating = true;
  
  current_fs = $(this).parent();
  next_fs = $(this).parent().next();
  
  //activate next step on progressbar using the index of next_fs
  $("#progressbar li").eq($("fieldset").index(next_fs)).addClass("active");
  
  //show the next fieldset
  next_fs.show(); 
  //hide the current fieldset with style
  current_fs.animate({opacity: 0}, {
    step: function(now, mx) {
      //as the opacity of current_fs reduces to 0 - stored in "now"
      //1. scale current_fs down to 80%
      scale = 1 - (1 - now) * 0.2;
      //2. bring next_fs from the right(50%)
      left = (now * 50)+"%";
      //3. increase opacity of next_fs to 1 as it moves in
      opacity = 1 - now;
      current_fs.css({
        'transform': 'scale('+scale+')',
        'position': 'absolute'
      });
      next_fs.css({'left': left, 'opacity': opacity});
    }, 
    duration: 800, 
    complete: function(){
      current_fs.hide();
      animating = false;
    }, 
    //this comes from the custom easing plugin
    easing: 'easeInOutBack'
  });
});

$(".previous").click(function(){
  if(animating) return false;
  animating = true;
  
  current_fs = $(this).parent();
  previous_fs = $(this).parent().prev();
  
  //de-activate current step on progressbar
  $("#progressbar li").eq($("fieldset").index(current_fs)).removeClass("active");
  
  //show the previous fieldset
  previous_fs.show(); 
  //hide the current fieldset with style
  current_fs.animate({opacity: 0}, {
    step: function(now, mx) {
      //as the opacity of current_fs reduces to 0 - stored in "now"
      //1. scale previous_fs from 80% to 100%
      scale = 0.8 + (1 - now) * 0.2;
      //2. take current_fs to the right(50%) - from 0%
      left = ((1-now) * 50)+"%";
      //3. increase opacity of previous_fs to 1 as it moves in
      opacity = 1 - now;
      current_fs.css({'left': left});
      previous_fs.css({'transform': 'scale('+scale+')', 'opacity': opacity});
    }, 
    duration: 800, 
    complete: function(){
      current_fs.hide();
      animating = false;
    }, 
    //this comes from the custom easing plugin
    easing: 'easeInOutBack'
  });
});
</script>

